# Portfólio pessoal — Daniel Simões

Reconstrução e evolução da identidade visual neon aprovada. Site estático com HTML, CSS e JS, pronto para GitHub Pages, sem banco e sem build.

## Conteúdo

- `index.html`: home responsiva, filtro de projetos, stack interativa, estatísticas reais de repositórios públicos via API GitHub (com fallback).
- `projetos/*/index.html`: 8 estudos de caso com transparência sobre o estágio dos projetos.
- `assets/`: imagens locais convertidas para WebP **sem alterar o retrato original** e CSS/JS sem dependências de CDN.
- `curriculo-daniel-simoes.pdf`: resumo profissional factual, sem referências acadêmicas nem métricas inventadas.
- `404.html` e `robots.txt`: suporte de navegação e indexação.

## Executar localmente

```bash
python -m http.server 8000
```
Acesse `http://localhost:8000`.

## Publicar no GitHub Pages

1. Crie um repositório **público** exclusivo, por exemplo `portfolio-daniel-simoes`.
2. Envie todo o conteúdo desta pasta à raiz da branch `main`.
3. Em Settings → Pages, selecione Deploy from a branch → main → /(root).
4. O endereço padrão será `https://danielsim9es.github.io/portfolio-daniel-simoes/` após a publicação.

**Não confundir** com ConnectehCode: esta é a marca pessoal de Daniel Simões.

## Observações

- GitHub API: números e repositórios aparecem só quando o navegador consegue consultar a API pública. Não há métrica de commits inventada.
- Projeto e imagem BusquePromo identificados como conceito, não como sistema em produção.
- Algumas URLs dos repositórios de estudo de caso podem ser privadas.
- Não informamos endereço final para Open Graph/canonical até confirmar o domínio publicado.
- Contato: WhatsApp +55 11 98110-7500 e contato@connectehcode.com.

## SEO após publicar

Depois de confirmar o endereço real, execute:

```bash
python tools/gerar-sitemap.py https://SEU-ENDERECO-HTTPS/
```

Publique os novos `sitemap.xml` e `robots.txt`. Atualize também `og:image` e adicione `rel="canonical"` com **URL absoluta**, pois uma URL relativa de imagem pode não gerar prévia em redes sociais. Não foi incluído domínio hipotético nos metadados.

## Verificações efetuadas

- Conferência estática de 10 arquivos HTML, links locais e rotas das páginas de estudo de caso.
- Verificação de JavaScript com `node --check`.
- Verificação de PDF e ausência de referências acadêmicas.
- Resposta HTTP 200 local para home, dois estudos, CSS, JS e currículo.
- **Limite da validação:** navegador Chromium com navegação bloqueada neste ambiente; testes visuais completos e mobile físico ainda precisam ser realizados após publicação.
