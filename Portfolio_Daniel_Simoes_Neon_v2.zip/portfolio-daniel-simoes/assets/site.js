(() => {
  const $=(selector,scope=document)=>scope.querySelector(selector);
  const $$=(selector,scope=document)=>Array.from(scope.querySelectorAll(selector));
  const menu=$('#main-menu'), toggle=$('#menu-toggle');
  if(menu&&toggle){toggle.addEventListener('click',()=>{const expanded=menu.classList.toggle('show');toggle.setAttribute('aria-expanded',String(expanded));toggle.textContent=expanded?'✕':'☰';});$$('a',menu).forEach(link=>link.addEventListener('click',()=>{menu.classList.remove('show');toggle.setAttribute('aria-expanded','false');toggle.textContent='☰';}));}
  const year=$('#copyright-year');if(year)year.textContent=String(new Date().getFullYear());
  let expanded=false,activeFilter='all';
  const allCards=$$('.project-card'), extra=allCards.filter(el=>el.classList.contains('extra-project'));
  const showAll=$('#show-all'), count=$('#project-count');
  function filterProjects(){
    let shown=0;
    allCards.forEach(card=>{const match=activeFilter==='all'||card.dataset.group===activeFilter;const limited=!expanded&&extra.includes(card);const visible=match&&!limited;card.hidden=!visible;if(visible)shown++;});
    if(showAll){showAll.textContent=expanded?'Mostrar destaques ↑':'Ver todos os projetos →';showAll.setAttribute('aria-expanded',String(expanded));}
    if(count)count.textContent=shown+' projeto'+(shown===1?'':'s')+' exibido'+(shown===1?'':'s')+' · selecione um cartão para conhecer o projeto';
  }
  if(showAll)showAll.addEventListener('click',()=>{expanded=!expanded;filterProjects();});
  $$('.filter-chip').forEach(btn=>btn.addEventListener('click',()=>{activeFilter=btn.dataset.filter||'all';expanded=true;$$('.filter-chip').forEach(x=>{const on=x===btn;x.classList.toggle('is-active',on);x.setAttribute('aria-pressed',String(on));});filterProjects();}));
  filterProjects();
  const categories={
   all:{tools:['React','TypeScript','Next.js','Node.js','Supabase','PostgreSQL','Docker','n8n'],text:'Ferramentas utilizadas ou exploradas nos projetos apresentados.',group:'all'},
   frontend:{tools:['React','Next.js','TypeScript','JavaScript','HTML','CSS'],text:'Interfaces e aplicações web — explore os sistemas e estudos de caso.',group:'Interfaces Web'},
   backend:{tools:['Node.js','NestJS','Python','APIs','PostgreSQL'],text:'Serviços, integrações e camadas de dados de aplicações digitais.',group:'Sistemas & SaaS'},
   data:{tools:['Python','Power BI','PostgreSQL','Supabase','IA aplicada'],text:'Projetos com foco em dados, busca, painéis ou inteligência.',group:'Dados & IA'},
   automation:{tools:['n8n','APIs','Webhooks','Integrações'],text:'Fluxos, automações e conexões entre serviços.',group:'Automação'},
   devops:{tools:['Git','GitHub','Docker','Deploy','CI/CD'],text:'Práticas e ferramentas de desenvolvimento, publicação e evolução.',group:'all'}
  };
  const details=$('#tech-stack-details'),desc=$('#stack-description'),related=$('#tech-related');
  const relatedProjects={
    all:['codexflow','radar-fusion','busquepromo','connectehcode'],
    frontend:['codexflow','radar-fusion','connectehcode','incentiva-pro','meu-ap-360','barber-ai-studio'],
    backend:['codexflow','radar-fusion','incentiva-pro','meu-ap-360','barber-ai-studio','n8n-workflows'],
    data:['radar-fusion','busquepromo','codexflow','incentiva-pro'],
    automation:['n8n-workflows','radar-fusion','busquepromo'],
    devops:['codexflow','connectehcode','n8n-workflows']
  };
  $$('.stack-category').forEach(btn=>btn.addEventListener('click',()=>{
    const item=categories[btn.dataset.tech]||categories.all;
    $$('.stack-category').forEach(x=>{const on=x===btn;x.classList.toggle('is-active',on);x.setAttribute('aria-pressed',String(on))});
    if(details)details.replaceChildren(...item.tools.map(tool=>{const tag=document.createElement('span');tag.className='chip-tech';tag.textContent=tool;return tag;}));
    if(desc)desc.textContent=item.text+' Os projetos exibidos abaixo são referências relacionadas à categoria.';
    if(related){
      const slugs=relatedProjects[btn.dataset.tech]||relatedProjects.all;
      related.replaceChildren(...slugs.map(id=>{
        const card=$('.project-card[data-slug="'+id+'"]');
        const link=document.createElement('a');link.href='./projetos/'+id+'/';link.className='tech-related-link';
        link.textContent=(card?.querySelector('.project-name')?.textContent||id).trim()+' ↗';return link;
      }));
    }
  }));
  const allTab=$('.stack-category[data-tech="all"]');
  if(allTab)allTab.click();
  const github=$('#github-live'),repoCount=$('#gh-repo-count'),lastUpdate=$('#gh-latest-update'),langs=$('#gh-languages');
  if(github){
   const controller=new AbortController();const timeout=setTimeout(()=>controller.abort(),8500);
   fetch('https://api.github.com/users/danielsim9es/repos?per_page=100&sort=pushed&direction=desc',{headers:{'Accept':'application/vnd.github+json'},signal:controller.signal})
    .then(async response=>{if(!response.ok)throw Error('GitHub temporariamente indisponível');return response.json()})
    .then(data=>{
      if(!Array.isArray(data))throw Error('Formato inválido');
      const repos=data.filter(x=>x&&!x.private&&!x.fork).sort((a,b)=>new Date(b.pushed_at)-new Date(a.pushed_at));
      if(repoCount)repoCount.textContent=String(repos.length)+(data.length===100?'+':'');
      const recent=repos[0]?.pushed_at;
      if(lastUpdate)lastUpdate.textContent=recent?new Intl.DateTimeFormat('pt-BR',{day:'2-digit',month:'short',year:'numeric'}).format(new Date(recent)):'—';
      const set=new Set(repos.map(x=>x.language).filter(Boolean));if(langs)langs.textContent=String(set.size);
      github.replaceChildren(...repos.slice(0,4).map(x=>{
        const el=document.createElement('article');el.className='gh-card';
        const a=document.createElement('a');a.href=x.html_url;a.rel='noopener noreferrer';a.target='_blank';a.textContent=x.name+' ↗';el.appendChild(a);
        const p=document.createElement('p');p.textContent=x.description||'Repositório público de código e desenvolvimento.';el.appendChild(p);
        const meta=document.createElement('span');meta.className='gh-meta';meta.textContent=(x.language||'Código')+' · atualização pública';el.appendChild(meta);
        return el;
      }));
      if(!repos.length)github.textContent='Nenhum repositório público disponível neste momento.';
    }).catch(()=>{
      github.replaceChildren();const p=document.createElement('p');p.className='gh-loading';p.textContent='Os dados ao vivo não puderam ser carregados. Veja a atividade diretamente no GitHub.';github.appendChild(p);
      if(repoCount)repoCount.textContent='—';if(lastUpdate)lastUpdate.textContent='—';if(langs)langs.textContent='—';
    }).finally(()=>clearTimeout(timeout));
  }
  const floating=document.createElement('a');floating.className='floating-wa';floating.href='https://wa.me/5511981107500?text='+encodeURIComponent('Olá Daniel, conheci seu portfólio e gostaria de conversar sobre um projeto.');floating.rel='noopener noreferrer';floating.target='_blank';floating.innerHTML='<span aria-hidden="true">✆</span> WhatsApp';floating.setAttribute('aria-label','Conversar com Daniel pelo WhatsApp');document.body.appendChild(floating);
})();
