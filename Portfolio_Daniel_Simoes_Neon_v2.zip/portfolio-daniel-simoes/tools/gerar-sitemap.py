#!/usr/bin/env python3
"""Gera sitemap e robots.txt usando somente a URL oficial após a publicação."""
from pathlib import Path
from html import escape
from urllib.parse import urlparse
import argparse

parser = argparse.ArgumentParser(description='Sitemap para GitHub Pages ou domínio próprio')
parser.add_argument('base_url', help='Ex.: https://danielsim9es.github.io/portfolio-daniel-simoes/')
args = parser.parse_args()
root = Path(__file__).resolve().parent.parent
base = args.base_url.rstrip('/') + '/'
assert urlparse(base).scheme == 'https' and urlparse(base).hostname, 'Forneça uma URL HTTPS válida.'
paths = [''] + [p.parent.relative_to(root).as_posix() + '/' for p in sorted((root / 'projetos').glob('*/index.html'))]
items = '\n'.join('  <url><loc>' + escape(base + suffix) + '</loc></url>' for suffix in paths)
xml = '<?xml version="1.0" encoding="UTF-8"?>\n<urlset xmlns="http://www.sitemaps.org/schemas/sitemap/0.9">\n' + items + '\n</urlset>\n'
(root / 'sitemap.xml').write_text(xml, encoding='utf8')
(root / 'robots.txt').write_text('User-agent: *\nAllow: /\nSitemap: ' + base + 'sitemap.xml\n', encoding='utf8')
print('Sitemap gerado com', len(paths), 'URLs para', base)
